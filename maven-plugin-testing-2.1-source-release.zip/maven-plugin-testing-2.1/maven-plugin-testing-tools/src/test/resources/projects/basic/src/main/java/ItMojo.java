import org.apache.maven.plugin.*;

/**
 * @goal it
 */
public class ItMojo
    extends AbstractMojo
{

    public void execute()
    {
    }

}
